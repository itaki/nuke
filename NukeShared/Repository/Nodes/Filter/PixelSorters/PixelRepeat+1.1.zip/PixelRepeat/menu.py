import nuke
nuke.menu('Nodes').addCommand('Filter/PixelRepeat', "nuke.createNode('PixelRepeat.gizmo')", icon='PixelRepeat.png')