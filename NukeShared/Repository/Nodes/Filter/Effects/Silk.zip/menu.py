''' Add this to your menu.py '''

##Hagbarth Tools
toolbar = nuke.toolbar("Nodes")
m = toolbar.addMenu("Hagbarth Tools", icon="h_tools.png")
m.addCommand("Silk", "nuke.createNode(\"h_silk\")", icon="h_silk.png")