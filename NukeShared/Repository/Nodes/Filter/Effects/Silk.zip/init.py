''' Add this to your init.py '''

##Hagbarth Tools
nuke.pluginAddPath('./hagbarth')
nuke.pluginAddPath('./hagbarth/icons')
nuke.pluginAddPath('./hagbarth/tools')
nuke.pluginAddPath('./hagbarth/grapichs')

