   SSSSSSSSSSSSSSS   iiii  lllllll kkkkkkkk           
 SS:::::::::::::::S i::::i l:::::l k::::::k           
S:::::SSSSSS::::::S  iiii  l:::::l k::::::k           
S:::::S     SSSSSSS        l:::::l k::::::k           
S:::::S            iiiiiii  l::::l  k:::::k    kkkkkkk
S:::::S            i:::::i  l::::l  k:::::k   k:::::k 
 S::::SSSS          i::::i  l::::l  k:::::k  k:::::k  
  SS::::::SSSSS     i::::i  l::::l  k:::::k k:::::k   
    SSS::::::::SS   i::::i  l::::l  k::::::k:::::k    
       SSSSSS::::S  i::::i  l::::l  k:::::::::::k     
            S:::::S i::::i  l::::l  k:::::::::::k     
            S:::::S i::::i  l::::l  k::::::k:::::k    
SSSSSSS     S:::::Si::::::il::::::lk::::::k k:::::k   
S::::::SSSSSS:::::Si::::::il::::::lk::::::k  k:::::k  
S:::::::::::::::SS i::::::il::::::lk::::::k   k:::::k 
 SSSSSSSSSSSSSSS   iiiiiiiillllllllkkkkkkkk    kkkkkkk
 _             _              _              _   _    
| |__ _  _    | |_  __ _ __ _| |__  __ _ _ _| |_| |_  
| '_ \ || |   | ' \/ _` / _` | '_ \/ _` | '_|  _| ' \ 
|_.__/\_, |   |_||_\__,_\__, |_.__/\__,_|_|  \__|_||_|
      |__/              |___/  

Thanks for downloading Silk for Nuke! 
This is a quick example installation guide.



Basic Installation:

1)
extract the "hagbarth" folder in the zip file into your .nuke/ folder
ie: /Users/JohnKnoll/.nuke/hagbarth/iconshagbarth/..

2)
Add the content of the init.py to your .nuke/init.py

3)
Add the content of the menu.py to your .nuke/menu.py



Custom installation:

1) 
extract the "hagbarth" folder into your gizmo folder.

2) 
Modify the content of the init.py to match your custom setup

3) 
Add the silk gizmo to your gizmo menu using:
m.addCommand("Silk", "nuke.createNode(\"silk\")", icon="h_silk.png")





