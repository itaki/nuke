"""Main modules that deal with the Nuke code editor widget."""
from .nuke_controllers import CodeEditor
from .nuke_script_editor import NukeScriptEditor
