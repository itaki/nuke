"""Module will initialize the logging system and import Nuke."""
from . import main, logger
